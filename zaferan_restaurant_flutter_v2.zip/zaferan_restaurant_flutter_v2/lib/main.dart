
import 'package:flutter/material.dart';
void main()=>runApp(const App());
class C{static const p=Color(0xFF5B1A8E),g=Color(0xFFFFD84D),o=Color(0xFFFF9A66),bg=Color(0xFFFFFBF2);}
class Food{final String n,d,c;final int price;const Food(this.n,this.d,this.c,this.price);}
const foods=[
 Food('چلو کباب مخصوص زعفران','چلو ایرانی، کباب مخصوص، گوجه کبابی و کره','کباب',320000),
 Food('جوجه کباب زعفرانی','جوجه مزه‌دار شده با زعفران، برنج و گوجه','کباب',280000),
 Food('کباب کوبیده','دو سیخ کباب کوبیده با برنج ایرانی','کباب',260000),
 Food('زرشک پلو با مرغ','برنج زعفرانی، مرغ، زرشک و خلال بادام','غذاهای ایرانی',240000),
 Food('قورمه سبزی','خورشت خانگی با برنج ایرانی','غذاهای ایرانی',220000),
 Food('فسنجان','خورشت گردو و رب انار با برنج ایرانی','غذاهای ایرانی',250000),
 Food('ماست موسیر','ماست چکیده و موسیر','پیش‌غذا',70000),
 Food('نوشابه','نوشیدنی سرد','نوشیدنی',35000),
];
String money(int n)=>n.toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'),(m)=>',');
class App extends StatelessWidget{const App({super.key});@override Widget build(BuildContext x)=>MaterialApp(
 debugShowCheckedModeBanner:false,title:'زعفران',theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:C.p),scaffoldBackgroundColor:C.bg),
 home:const Directionality(textDirection:TextDirection.rtl,child:Home()));}
class Home extends StatefulWidget{const Home({super.key});@override State<Home> createState()=>_Home();}
class _Home extends State<Home>{
 final cart=<Food>[];String cat='همه';final cats=['همه','کباب','غذاهای ایرانی','پیش‌غذا','نوشیدنی'];
 int get total=>cart.fold(0,(a,b)=>a+b.price);
 void add(Food f){setState(()=>cart.add(f));}
 @override Widget build(BuildContext c){final list=cat=='همه'?foods:foods.where((f)=>f.c==cat).toList();return Scaffold(
 appBar:AppBar(backgroundColor:C.p,foregroundColor:Colors.white,centerTitle:true,title:const Text('زعفران',style:TextStyle(fontWeight:FontWeight.w900)),
 actions:[IconButton(onPressed:()=>showCart(c),icon:Badge(isLabelVisible:cart.isNotEmpty,label:Text('${cart.length}'),child:const Icon(Icons.shopping_bag_outlined)))],
 body:CustomScrollView(slivers:[
  SliverToBoxAdapter(child:Container(margin:const EdgeInsets.all(16),padding:const EdgeInsets.all(18),decoration:BoxDecoration(gradient:const LinearGradient(colors:[C.g,C.o]),borderRadius:BorderRadius.circular(28)),child:Row(children:[
   ClipRRect(borderRadius:BorderRadius.circular(50),child:Image.asset('assets/logo.webp',width:90,height:90,fit:BoxFit.cover)),const SizedBox(width:14),
   const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('رستوران زعفران',style:TextStyle(fontSize:23,fontWeight:FontWeight.w900,color:C.p)),SizedBox(height:5),Text('بندرانزلی • گیلان',style:TextStyle(fontWeight:FontWeight.w600)),SizedBox(height:7),Text('سفارش آنلاین غذای تازه و خوشمزه',style:TextStyle(fontSize:12))]))] ))),
  const SliverToBoxAdapter(child:Padding(padding:EdgeInsets.fromLTRB(16,0,16,8),child:Text('دسته‌بندی‌ها',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)))),
  SliverToBoxAdapter(child:SizedBox(height:52,child:ListView.separated(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:16),itemCount:cats.length,separatorBuilder:(_,__)=>const SizedBox(width:8),itemBuilder:(_,i)=>ChoiceChip(label:Text(cats[i]),selected:cat==cats[i],selectedColor:C.g,onSelected:(_)=>setState(()=>cat=cats[i]))))),
  const SliverToBoxAdapter(child:Padding(padding:EdgeInsets.fromLTRB(16,12,16,8),child:Text('منوی رستوران',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)))),
  SliverPadding(padding:const EdgeInsets.fromLTRB(16,0,16,110),sliver:SliverList.builder(itemCount:list.length,itemBuilder:(_,i)=>Card(
   margin:const EdgeInsets.only(bottom:12),child:ListTile(
    contentPadding:const EdgeInsets.all(10),leading:Container(width:70,height:70,decoration:BoxDecoration(borderRadius:BorderRadius.circular(16),gradient:const LinearGradient(colors:[C.g,C.o])),child:const Icon(Icons.restaurant_menu,color:C.p)),
    title:Text(list[i].n,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Padding(padding:const EdgeInsets.only(top:5),child:Text('${list[i].d}\n${money(list[i].price)} تومان',maxLines:2,overflow:TextOverflow.ellipsis)),
    trailing:IconButton.filled(style:IconButton.styleFrom(backgroundColor:C.p,foregroundColor:Colors.white),onPressed:()=>add(list[i]),icon:const Icon(Icons.add)))))),
 ]),bottomNavigationBar:cart.isEmpty?null:SafeArea(child:Padding(padding:const EdgeInsets.fromLTRB(16,8,16,12),child:FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:C.p,padding:const EdgeInsets.all(15)),onPressed:()=>showCart(c),icon:const Icon(Icons.shopping_bag_outlined),label:Text('سبد خرید • ${money(total)} تومان')))));
 }
 void showCart(BuildContext c)=>showModalBottomSheet(context:c,isScrollControlled:true,builder:(_)=>Directionality(textDirection:TextDirection.rtl,child:SafeArea(child:SizedBox(height:MediaQuery.of(c).size.height*.72,child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
  const Text('سبد خرید',style:TextStyle(fontSize:23,fontWeight:FontWeight.w900)),const SizedBox(height:10),
  Expanded(child:cart.isEmpty?const Center(child:Text('سبد خالی است')):ListView.builder(itemCount:cart.length,itemBuilder:(_,i)=>ListTile(title:Text(cart[i].n),subtitle:Text('${money(cart[i].price)} تومان'),trailing:IconButton(onPressed:(){setState(()=>cart.removeAt(i));Navigator.pop(c);showCart(c);},icon:const Icon(Icons.delete_outline))))),
  if(cart.isNotEmpty)Text('مجموع: ${money(total)} تومان',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:18)),const SizedBox(height:10),
  if(cart.isNotEmpty)SizedBox(width:double.infinity,child:FilledButton(style:FilledButton.styleFrom(backgroundColor:C.p,padding:const EdgeInsets.all(15)),onPressed:(){Navigator.pop(c);checkout(c);},child:const Text('ادامه ثبت سفارش')))
 ])))));
 void checkout(BuildContext c)=>Navigator.push(c,MaterialPageRoute(builder:(_)=>Directionality(textDirection:TextDirection.rtl,child:Checkout(total:total))));
}
class Checkout extends StatefulWidget{final int total;const Checkout({super.key,required this.total});@override State<Checkout> createState()=>_Checkout();}
class _Checkout extends State<Checkout>{final a=TextEditingController(),coupon=TextEditingController();bool map=false,ok=false;@override void dispose(){a.dispose();coupon.dispose();super.dispose();}
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('ثبت سفارش')),body:ListView(padding:const EdgeInsets.all(16),children:[
  const Text('آدرس تحویل',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:8),
  TextField(controller:a,maxLines:2,decoration:const InputDecoration(hintText:'آدرس کامل',border:OutlineInputBorder())),const SizedBox(height:8),
  OutlinedButton.icon(onPressed:()=>setState(()=>map=!map),icon:const Icon(Icons.location_on_outlined),label:Text(map?'لوکیشن انتخاب شد':'انتخاب لوکیشن روی نقشه')),
  if(map)Container(height:120,margin:const EdgeInsets.only(bottom:16),decoration:BoxDecoration(color:Colors.black12,borderRadius:BorderRadius.circular(18)),child:const Center(child:Text('محل اتصال نقشه واقعی'))),
  const Text('کد تخفیف',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:8),
  Row(children:[Expanded(child:TextField(controller:coupon,decoration:const InputDecoration(hintText:'مثلاً ZAFARAN10',border:OutlineInputBorder()))),const SizedBox(width:8),FilledButton(onPressed:()=>setState(()=>ok=coupon.text.isNotEmpty),child:const Text('اعمال'))]),
  if(ok)const Padding(padding:EdgeInsets.only(top:8),child:Text('کد وارد شد؛ اعتبار آن در سرور بررسی می‌شود.',style:TextStyle(color:Colors.green))),
  const SizedBox(height:20),Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
   Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('مبلغ غذا'),Text('${money(widget.total)} تومان')]),const SizedBox(height:8),
   const Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text('هزینه ارسال'),Text('پس از تعیین محدوده')]),const Divider(),
   Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('قابل پرداخت',style:TextStyle(fontWeight:FontWeight.bold)),Text('${money(widget.total)} تومان',style:const TextStyle(fontWeight:FontWeight.bold))])
  ]))),
  const SizedBox(height:18),SizedBox(width:double.infinity,child:FilledButton(style:FilledButton.styleFrom(backgroundColor:C.p,padding:const EdgeInsets.all(16)),onPressed:()=>showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('درگاه پرداخت'),content:const Text('این بخش آماده اتصال به درگاه پرداخت واقعی است.'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('باشه'))])),child:const Text('ادامه به پرداخت')))
 ]));}
