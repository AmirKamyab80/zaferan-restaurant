
import 'package:flutter/material.dart';

void main() => runApp(const ZaferanApp());

const purple = Color(0xFF5B1A8E);
const gold = Color(0xFFFFC928);
const cream = Color(0xFFFFFBF5);
const green = Color(0xFF2E9B68);

class Food {
  final String name;
  final String category;
  final int price;
  final String description;
  final bool isMain;

  const Food({
    required this.name,
    required this.category,
    required this.price,
    required this.description,
    required this.isMain,
  });
}

const foods = [
  Food(name: 'چلو کباب مخصوص زعفران', category: 'کباب‌ها', price: 320000,
      description: 'کباب مخصوص زعفران همراه برنج ایرانی و گوجه کبابی', isMain: true),
  Food(name: 'جوجه کباب زعفرانی', category: 'کباب‌ها', price: 280000,
      description: 'جوجه مزه‌دار شده با زعفران و ادویه مخصوص زعفران', isMain: true),
  Food(name: 'کباب کوبیده', category: 'کباب‌ها', price: 260000,
      description: 'کوبیده تازه با برنج ایرانی و گوجه کبابی', isMain: true),
  Food(name: 'زرشک پلو با مرغ', category: 'غذاهای ایرانی', price: 240000,
      description: 'برنج ایرانی با زرشک و مرغ زعفرانی', isMain: true),
  Food(name: 'قورمه سبزی', category: 'غذاهای ایرانی', price: 220000,
      description: 'قورمه سبزی جاافتاده با برنج ایرانی', isMain: true),
  Food(name: 'فسنجان', category: 'غذاهای ایرانی', price: 250000,
      description: 'فسنجان با گردو و رب انار', isMain: true),
  Food(name: 'سالاد فصل', category: 'پیش‌غذا و مخلفات', price: 90000,
      description: 'سالاد تازه روز', isMain: false),
  Food(name: 'ماست موسیر', category: 'پیش‌غذا و مخلفات', price: 70000,
      description: 'ماست موسیر خنک', isMain: false),
  Food(name: 'نوشابه', category: 'نوشیدنی‌ها', price: 35000,
      description: 'نوشابه قوطی', isMain: false),
];

String money(int n) => n.toString().replaceAllMapped(
  RegExp(r'\B(?=(\d{3})+(?!\d))'),
  (_) => ',',
);

class CartLine {
  final Food food;
  int qty;
  CartLine(this.food, this.qty);
}

class ZaferanApp extends StatelessWidget {
  const ZaferanApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'رستوران زعفران',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: purple),
        fontFamily: 'sans',
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  final List<CartLine> cart = [];
  final Set<String> favorites = {};
  int tab = 0;

  int get foodSubtotal => cart
      .where((x) => x.food.isMain)
      .fold(0, (s, x) => s + x.food.price * x.qty);

  int get cartSubtotal =>
      cart.fold(0, (s, x) => s + x.food.price * x.qty);

  int get itemCount => cart.fold(0, (s, x) => s + x.qty);

  bool get canCheckout => foodSubtotal >= 250000;

  void add(Food food) {
    setState(() {
      final i = cart.indexWhere((x) => x.food.name == food.name);
      if (i >= 0) {
        cart[i].qty++;
      } else {
        cart.add(CartLine(food, 1));
      }
    });
  }

  void changeQty(Food food, int delta) {
    setState(() {
      final i = cart.indexWhere((x) => x.food.name == food.name);
      if (i < 0) return;
      cart[i].qty += delta;
      if (cart[i].qty <= 0) cart.removeAt(i);
    });
  }

  void openFood(Food food) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => FoodSheet(
        food: food,
        onAdd: () {
          add(food);
          Navigator.pop(context);
        },
      ),
    );
  }

  void showCart() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => CartSheet(
        cart: cart,
        subtotal: cartSubtotal,
        foodSubtotal: foodSubtotal,
        canCheckout: canCheckout,
        onPlus: (f) => changeQty(f, 1),
        onMinus: (f) => changeQty(f, -1),
        onCheckout: () {
          Navigator.pop(context);
          if (canCheckout) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CheckoutPage(
                  subtotal: cartSubtotal,
                  foodSubtotal: foodSubtotal,
                ),
              ),
            );
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(
        cartCount: itemCount,
        favorites: favorites,
        onFavorite: (f) => setState(() {
          favorites.contains(f.name)
              ? favorites.remove(f.name)
              : favorites.add(f.name);
        }),
        onAdd: add,
        onOpen: openFood,
      ),
      SearchPage(onOpen: openFood, onAdd: add),
      FavoritesPage(
        favorites: favorites,
        onOpen: openFood,
        onAdd: add,
      ),
      const ProfilePage(),
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: pages[tab],
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (v) => setState(() => tab = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
            NavigationDestination(icon: Icon(Icons.search), label: 'جستجو'),
            NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'علاقه‌مندی‌ها'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'پروفایل'),
          ],
        ),
        floatingActionButton: cart.isEmpty
            ? null
            : FloatingActionButton.extended(
                backgroundColor: purple,
                foregroundColor: Colors.white,
                onPressed: showCart,
                icon: Badge(
                  isLabelVisible: itemCount > 0,
                  label: Text('$itemCount'),
                  child: const Icon(Icons.shopping_bag_outlined),
                ),
                label: Text('سبد • ${money(cartSubtotal)}'),
              ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final int cartCount;
  final Set<String> favorites;
  final void Function(Food) onFavorite;
  final void Function(Food) onAdd;
  final void Function(Food) onOpen;

  const HomePage({
    super.key,
    required this.cartCount,
    required this.favorites,
    required this.onFavorite,
    required this.onAdd,
    required this.onOpen,
  });

  @override
  Widget build(BuildContext context) {
    final popular = foods.where((f) => f.isMain).take(4).toList();

    return CustomScrollView(
      slivers: [
        SliverAppBar(
          pinned: true,
          expandedHeight: 205,
          backgroundColor: purple,
          foregroundColor: Colors.white,
          flexibleSpace: FlexibleSpaceBar(
            background: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [purple, Color(0xFF7A2BB0)],
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                ),
              ),
              padding: const EdgeInsets.fromLTRB(20, 72, 20, 18),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('زعفران', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: gold)),
                  SizedBox(height: 4),
                  Text('غذای اصیل، تازه و گرم در بندرانزلی',
                      style: TextStyle(color: Colors.white70, fontSize: 14)),
                  SizedBox(height: 18),
                  SearchBar(
                    leading: Icon(Icons.search),
                    hintText: 'جستجوی غذا یا دسته‌بندی...',
                    backgroundColor: WidgetStatePropertyAll(Colors.white),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
          ],
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _sectionTitle('پیشنهاد امروز', 'ویژه زعفران'),
                const SizedBox(height: 10),
                Container(
                  height: 150,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFFD84D), Color(0xFFFFA46B)],
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(18),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('چلو کباب مخصوص زعفران',
                                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: purple)),
                              const SizedBox(height: 6),
                              const Text('پیشنهاد ویژه امروز'),
                              const Spacer(),
                              FilledButton(
                                style: FilledButton.styleFrom(backgroundColor: purple, foregroundColor: Colors.white),
                                onPressed: () => onOpen(popular.first),
                                child: const Text('مشاهده غذا'),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Icon(Icons.restaurant, size: 86, color: purple),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                _sectionTitle('دسته‌بندی‌ها', ''),
                const SizedBox(height: 10),
                SizedBox(
                  height: 82,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: const [
                      CategoryTile(icon: Icons.kebab_dining, title: 'کباب‌ها'),
                      CategoryTile(icon: Icons.rice_bowl, title: 'غذاهای ایرانی'),
                      CategoryTile(icon: Icons.soup_kitchen, title: 'پیش‌غذا و مخلفات'),
                      CategoryTile(icon: Icons.local_drink, title: 'نوشیدنی‌ها'),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                _sectionTitle('پرفروش‌های زعفران', 'مشاهده همه'),
              ],
            ),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          sliver: SliverGrid(
            delegate: SliverChildBuilderDelegate(
              (_, i) => FoodCard(
                food: popular[i],
                favorite: favorites.contains(popular[i].name),
                onFavorite: () => onFavorite(popular[i]),
                onAdd: () => onAdd(popular[i]),
                onOpen: () => onOpen(popular[i]),
              ),
              childCount: popular.length,
            ),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: .72,
            ),
          ),
        ),
      ],
    );
  }

  Widget _sectionTitle(String a, String b) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(a, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
      if (b.isNotEmpty) Text(b, style: const TextStyle(color: purple, fontWeight: FontWeight.bold)),
    ],
  );
}

class CategoryTile extends StatelessWidget {
  final IconData icon;
  final String title;
  const CategoryTile({super.key, required this.icon, required this.title});

  @override
  Widget build(BuildContext context) => Container(
    width: 105,
    margin: const EdgeInsets.only(left: 10),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: Colors.black12),
    ),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: purple),
        const SizedBox(height: 5),
        Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
      ],
    ),
  );
}

class FoodCard extends StatelessWidget {
  final Food food;
  final bool favorite;
  final VoidCallback onFavorite;
  final VoidCallback onAdd;
  final VoidCallback onOpen;

  const FoodCard({
    super.key,
    required this.food,
    required this.favorite,
    required this.onFavorite,
    required this.onAdd,
    required this.onOpen,
  });

  @override
  Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(20),
    onTap: onOpen,
    child: Card(
      elevation: 0,
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Container(
              width: double.infinity,
              color: const Color(0xFFF1E8F6),
              child: Stack(
                children: [
                  const Center(child: Icon(Icons.restaurant, size: 64, color: purple)),
                  Positioned(
                    top: 8, right: 8,
                    child: IconButton(
                      style: IconButton.styleFrom(backgroundColor: Colors.white),
                      onPressed: onFavorite,
                      icon: Icon(favorite ? Icons.favorite : Icons.favorite_border,
                          color: favorite ? Colors.red : purple),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 4),
            child: Text(food.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text('${money(food.price)} تومان', style: const TextStyle(color: purple, fontWeight: FontWeight.bold)),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: onAdd,
                icon: const Icon(Icons.add, size: 18),
                label: const Text('افزودن'),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

class FoodSheet extends StatefulWidget {
  final Food food;
  final VoidCallback onAdd;
  const FoodSheet({super.key, required this.food, required this.onAdd});

  @override
  State<FoodSheet> createState() => _FoodSheetState();
}

class _FoodSheetState extends State<FoodSheet> {
  int qty = 1;
  bool salad = false;
  bool yogurt = false;
  final note = TextEditingController();

  int get extras => (salad ? 90000 : 0) + (yogurt ? 70000 : 0);

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Container(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
        decoration: const BoxDecoration(
          color: cream,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(child: Container(width: 45, height: 5, decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(10)))),
                const SizedBox(height: 18),
                Container(height: 190, decoration: BoxDecoration(color: const Color(0xFFF1E8F6), borderRadius: BorderRadius.circular(22)),
                  child: const Center(child: Icon(Icons.restaurant, size: 90, color: purple))),
                const SizedBox(height: 14),
                Text(widget.food.name, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
                const SizedBox(height: 5),
                Text(widget.food.description, style: const TextStyle(color: Colors.black54, height: 1.5)),
                const SizedBox(height: 8),
                Text('${money(widget.food.price)} تومان', style: const TextStyle(fontSize: 20, color: purple, fontWeight: FontWeight.w900)),
                const Divider(height: 30),
                const Text('انتخاب مخلفات', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                CheckboxListTile(value: salad, onChanged: (v) => setState(() => salad = v ?? false), title: const Text('سالاد فصل'), contentPadding: EdgeInsets.zero),
                CheckboxListTile(value: yogurt, onChanged: (v) => setState(() => yogurt = v ?? false), title: const Text('ماست موسیر'), contentPadding: EdgeInsets.zero),
                const SizedBox(height: 4),
                const Text('توضیحات سفارش', style: TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                TextField(controller: note, maxLines: 2, decoration: const InputDecoration(hintText: 'مثلاً پیاز نذارید', border: OutlineInputBorder())),
                const SizedBox(height: 16),
                Row(
                  children: [
                    const Text('تعداد', style: TextStyle(fontWeight: FontWeight.bold)),
                    const Spacer(),
                    IconButton(onPressed: () => setState(() { if (qty > 1) qty--; }), icon: const Icon(Icons.remove_circle_outline)),
                    Text('$qty', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    IconButton(onPressed: () => setState(() => qty++), icon: const Icon(Icons.add_circle, color: purple)),
                  ],
                ),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: () {
                      for (var i = 0; i < qty; i++) widget.onAdd();
                    },
                    icon: const Icon(Icons.shopping_bag_outlined),
                    label: Text('افزودن به سبد • ${money((widget.food.price + extras) * qty)} تومان'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CartSheet extends StatelessWidget {
  final List<CartLine> cart;
  final int subtotal;
  final int foodSubtotal;
  final bool canCheckout;
  final void Function(Food) onPlus;
  final void Function(Food) onMinus;
  final VoidCallback onCheckout;

  const CartSheet({
    super.key,
    required this.cart,
    required this.subtotal,
    required this.foodSubtotal,
    required this.canCheckout,
    required this.onPlus,
    required this.onMinus,
    required this.onCheckout,
  });

  @override
  Widget build(BuildContext context) {
    final onlyExtras = cart.isNotEmpty && foodSubtotal < 250000;
    final remaining = (250000 - foodSubtotal).clamp(0, 250000);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Container(
        height: MediaQuery.of(context).size.height * .82,
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
        decoration: const BoxDecoration(
          color: cream,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Column(
          children: [
            const Text('سبد خرید', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            Expanded(
              child: cart.isEmpty
                  ? const Center(child: Text('سبد خرید خالی است'))
                  : ListView.separated(
                      itemCount: cart.length,
                      separatorBuilder: (_, __) => const Divider(),
                      itemBuilder: (_, i) {
                        final line = cart[i];
                        return Row(
                          children: [
                            Container(width: 58, height: 58, decoration: BoxDecoration(color: const Color(0xFFF1E8F6), borderRadius: BorderRadius.circular(14)),
                              child: const Icon(Icons.restaurant, color: purple)),
                            const SizedBox(width: 10),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(line.food.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                              Text('${money(line.food.price * line.qty)} تومان', style: const TextStyle(color: purple, fontWeight: FontWeight.bold)),
                            ])),
                            Row(children: [
                              IconButton(onPressed: () => onMinus(line.food), icon: const Icon(Icons.remove_circle_outline)),
                              Text('${line.qty}', style: const TextStyle(fontWeight: FontWeight.bold)),
                              IconButton(onPressed: () => onPlus(line.food), icon: const Icon(Icons.add_circle, color: purple)),
                            ]),
                          ],
                        );
                      },
                    ),
            ),
            if (onlyExtras)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: const Color(0xFFFFF2D8), borderRadius: BorderRadius.circular(14)),
                child: Text(
                  'برای ثبت سفارش باید حداقل ۲۵۰,۰۰۰ تومان غذای اصلی در سبد باشد. ${remaining > 0 ? 'هنوز ${money(remaining)} تومان مانده است.' : ''}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            const SizedBox(height: 10),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('مجموع غذاها'),
              Text('${money(subtotal)} تومان', style: const TextStyle(fontWeight: FontWeight.bold)),
            ]),
            const SizedBox(height: 10),
            SizedBox(width: double.infinity, child: FilledButton(
              onPressed: canCheckout ? onCheckout : null,
              child: Text(canCheckout ? 'تکمیل سفارش' : 'حداقل سفارش ۲۵۰,۰۰۰ تومان'),
            )),
          ],
        ),
      ),
    );
  }
}

class SearchPage extends StatefulWidget {
  final void Function(Food) onOpen;
  final void Function(Food) onAdd;
  const SearchPage({super.key, required this.onOpen, required this.onAdd});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  String q = '';
  @override
  Widget build(BuildContext context) {
    final result = foods.where((f) => f.name.contains(q) || f.category.contains(q)).toList();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: SafeArea(
        child: Column(
          children: [
            Padding(padding: const EdgeInsets.all(16), child: TextField(
              autofocus: true,
              onChanged: (v) => setState(() => q = v),
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'جستجوی غذا...', border: OutlineInputBorder()),
            )),
            Expanded(child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: result.length,
              itemBuilder: (_, i) => ListTile(
                onTap: () => widget.onOpen(result[i]),
                leading: CircleAvatar(backgroundColor: const Color(0xFFF1E8F6), child: const Icon(Icons.restaurant, color: purple)),
                title: Text(result[i].name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${money(result[i].price)} تومان'),
                trailing: IconButton(onPressed: () => widget.onAdd(result[i]), icon: const Icon(Icons.add_circle, color: purple)),
              ),
            )),
          ],
        ),
      ),
    );
  }
}

class FavoritesPage extends StatelessWidget {
  final Set<String> favorites;
  final void Function(Food) onOpen;
  final void Function(Food) onAdd;
  const FavoritesPage({super.key, required this.favorites, required this.onOpen, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    final list = foods.where((f) => favorites.contains(f.name)).toList();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: list.isEmpty
              ? const Center(child: Text('هنوز غذایی به علاقه‌مندی‌ها اضافه نکرده‌ای'))
              : ListView(children: list.map((f) => Card(child: ListTile(
                  onTap: () => onOpen(f),
                  leading: const CircleAvatar(backgroundColor: Color(0xFFF1E8F6), child: Icon(Icons.restaurant, color: purple)),
                  title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('${money(f.price)} تومان'),
                  trailing: IconButton(onPressed: () => onAdd(f), icon: const Icon(Icons.add_circle, color: purple)),
                ))).toList()),
        ),
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const CircleAvatar(radius: 38, backgroundColor: Color(0xFFF1E8F6), child: Icon(Icons.person, size: 42, color: purple)),
          const SizedBox(height: 10),
          const Center(child: Text('کاربر زعفران', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
          const SizedBox(height: 22),
          _profileTile(Icons.receipt_long, 'سفارش‌های من', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const OrdersPage()));
          }),
          _profileTile(Icons.location_on_outlined, 'آدرس‌های من', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const AddressPage()));
          }),
          _profileTile(Icons.discount_outlined, 'تخفیف‌ها و کدهای تخفیف', () {}),
          _profileTile(Icons.settings_outlined, 'تنظیمات', () {}),
          _profileTile(Icons.support_agent, 'پشتیبانی', () {}),
        ],
      ),
    ),
  );

  Widget _profileTile(IconData icon, String title, VoidCallback onTap) => Card(
    child: ListTile(
      onTap: onTap,
      leading: Icon(icon, color: purple),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      trailing: const Icon(Icons.chevron_left),
    ),
  );
}

class CheckoutPage extends StatelessWidget {
  final int subtotal;
  final int foodSubtotal;
  const CheckoutPage({super.key, required this.subtotal, required this.foodSubtotal});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تکمیل سفارش')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _box('آدرس تحویل', Icons.location_on_outlined, 'بندرانزلی — انتخاب موقعیت روی نقشه'),
            const SizedBox(height: 12),
            _box('هزینه ارسال', Icons.delivery_dining, 'بر اساس فاصله از رستوران محاسبه می‌شود'),
            const SizedBox(height: 12),
            _box('کد تخفیف', Icons.discount_outlined, 'کد تخفیف را وارد کنید'),
            const SizedBox(height: 12),
            Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
              _row('مجموع غذاها', '${money(subtotal)} تومان'),
              _row('هزینه ارسال', 'پس از انتخاب موقعیت'),
              const Divider(),
              _row('قابل پرداخت', '${money(subtotal)} تومان', bold: true),
            ]))),
            const SizedBox(height: 12),
            Card(child: RadioListTile<bool>(
              value: true, groupValue: true, onChanged: (_) {},
              title: const Text('پرداخت اینترنتی'),
              secondary: const Icon(Icons.credit_card, color: purple),
            )),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity, child: FilledButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TrackingPage())),
              icon: const Icon(Icons.lock),
              label: const Text('پرداخت و ثبت سفارش'),
            )),
          ],
        ),
      ),
    );
  }

  Widget _box(String title, IconData icon, String subtitle) => Card(
    child: ListTile(
      leading: Icon(icon, color: purple),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_left),
    ),
  );

  Widget _row(String a, String b, {bool bold = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(a, style: TextStyle(fontWeight: bold ? FontWeight.w900 : FontWeight.normal)),
      Text(b, style: TextStyle(fontWeight: bold ? FontWeight.w900 : FontWeight.normal, color: bold ? purple : null)),
    ]),
  );
}

class TrackingPage extends StatelessWidget {
  const TrackingPage({super.key});

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('پیگیری سفارش')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('سفارش شما #۱۲۵۸', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              const Text('وضعیت سفارش به‌صورت لحظه‌ای نمایش داده می‌شود'),
              const SizedBox(height: 20),
              _step('سفارش ثبت شد', true),
              _step('رستوران سفارش را تأیید کرد', true),
              _step('در حال آماده‌سازی', true),
              _step('تحویل به پیک', false),
              _step('تحویل داده شد', false),
            ],
          ))),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: const Color(0xFFE9F7EF), borderRadius: BorderRadius.circular(16)),
            child: const Row(children: [
              Icon(Icons.schedule, color: green),
              SizedBox(width: 10),
              Expanded(child: Text('زمان تقریبی آماده شدن سفارش: ۳۰ تا ۴۵ دقیقه')),
            ]),
          ),
        ],
      ),
    ),
  );

  Widget _step(String text, bool done) => Padding(
    padding: const EdgeInsets.only(bottom: 15),
    child: Row(children: [
      Icon(done ? Icons.check_circle : Icons.radio_button_unchecked, color: done ? green : Colors.black26),
      const SizedBox(width: 10),
      Text(text, style: TextStyle(fontWeight: done ? FontWeight.bold : FontWeight.normal)),
    ]),
  );
}

class OrdersPage extends StatelessWidget {
  const OrdersPage({super.key});

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('سفارش‌های من')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _order('۲۵ شهریور', 'چلو کباب مخصوص زعفران × ۲', '۶۴۰,۰۰۰ تومان'),
          _order('۲۰ شهریور', 'جوجه کباب زعفرانی × ۳', '۸۴۰,۰۰۰ تومان'),
          _order('۱۵ شهریور', 'قورمه سبزی × ۱', '۲۲۰,۰۰۰ تومان'),
        ],
      ),
    ),
  );

  Widget _order(String date, String items, String price) => Card(
    child: ListTile(
      title: Text(items, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('$date • $price'),
      trailing: FilledButton(onPressed: () {}, child: const Text('سفارش مجدد')),
    ),
  );
}

class AddressPage extends StatelessWidget {
  const AddressPage({super.key});

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('آدرس‌های من')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(child: ListTile(
            leading: const Icon(Icons.location_on, color: purple),
            title: const Text('آدرس اصلی', style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: const Text('بندرانزلی — موقعیت انتخاب‌شده روی نقشه'),
            trailing: IconButton(onPressed: () {}, icon: const Icon(Icons.edit_outlined)),
          )),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: OutlinedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.add_location_alt_outlined),
            label: const Text('افزودن آدرس جدید'),
          )),
        ],
      ),
    ),
  );
}
